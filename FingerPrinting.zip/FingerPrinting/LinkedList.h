typedef struct node_type
{
    long long hashValue;
    struct node_type *link;
}node;
typedef node *list;

double size(list head)
{
	/* returns the size of the list */
    double listSize = 0;
    list temp = head;
    while(temp != NULL)
    {
        temp = temp->link;
        listSize++;
    }
    return listSize;
}

double compare(list head1, list head2)
{
	/*compares the hashValues in the given two linked lists and reurns plagiarism percent*/
    list temp1 = head1;
    double count = 0;
    while(temp1 != NULL)
    {
        list temp2 = head2;
        while(temp2 != NULL)
        {
            if(temp1->hashValue == temp2->hashValue)// checks for matching values in given two linked lists
            {
                count++;
                break;
            }
            temp2 = temp2->link;
        }
        temp1 = temp1->link;
    }
   //calculates the plagiarism percent
    double percent = ((count*2)/(size(head1)+size(head2)))*100;
    return percent;
}

list hash(list head, char *str)
{
	/* creeates a list of hash values for a given string*/
    list tail = head;
    list listTemp = NULL;
    int i = 0;
    long long sum = 0;
    while(i < strlen(str) - 5)// gram value is 5
    {
        sum = str[i]*pow(5, 5) + str[i+1]*pow(5,4)+str[i+2]*pow(5,3)+str[i+3]*pow(5,2)+str[i+4]*5;
        sum = sum % 10007;
        if(i == 0)
        {
            head = (list)malloc(sizeof(node));
            head->hashValue = sum;
            head->link = NULL;
            tail = head;
        }
        else
        {
            listTemp = (list)malloc(sizeof(node));
            listTemp->hashValue = sum;
            tail->link = listTemp;
            tail = tail->link;
            tail->link = NULL;
        }
        i++;
    }
    return head;//returns the list of hash values
}
