char *getData(FILE* fp, size_t size){
    /* This function gets all the data in the file except special characters
    except "_" into a string and returns that string. It takes two arguments , file and default size */
    char *str;
    int ch;
    size_t len = 0;
    str = realloc(NULL, sizeof(char)*size);//allocates space for str
    if(!str)return str;
    while(EOF!=(ch=fgetc(fp))){
        if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch == '_') || (ch >= '0' && ch <= '9'))//takes only alphabets, "_", and numbers
        {
            if(ch >= 'A' && ch <= 'Z')//converts capital letters into small letters
                ch = ch + 32;
            str[len++]=ch;//puts each character into the string and increments len

        }

        else
            continue;
        if(len==size){
            str = realloc(str, sizeof(char)*(size+=16));//if len exceeds size, size is incremented by 20 and the same is reallocate to str
            if(!str)return str;
        }
    }
    str[len++]='\0';
    return realloc(str, sizeof(char)*len);//if len exceeds size, size is incremented by 20 and the same is reallocate to str
}

int getAllFiles(char files[100][100], char path[100])
{
    /* This functio gets all the .txt files in the given path*/
	DIR *dir;
	struct dirent* f;
	dir = opendir(path);
	int i = 0;
	while((f = readdir(dir)) != NULL)// puts each file in the given path into f one by one
	{
		if (!strcmp (f->d_name, "."))// checks for current directory
            continue;
        if (!strcmp (f->d_name, ".."))// checks for parent directory
            continue;
        int len = strlen(f->d_name);
        if((f->d_name[len-1] == 't') && (f->d_name[len-2] == 'x') && (f->d_name[len-3] == 't') && (f->d_name[len-4] == '.'))
        	{
                // tests for .txt files
        		char *temp = (char*)malloc(sizeof(char)*100);
        		temp = f->d_name;
        		//printf("%s\n", temp);
        		strcpy(files[i], temp);
        		//printf("%s\n", files[i]);
        		i++;
	        }
	}
    // returns number of files
	int noOfFiles = i;
	return noOfFiles;
}