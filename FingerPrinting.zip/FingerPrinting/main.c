#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <sys/types.h>
#include <string.h>
#include "Data.h"
#include "LinkedList.h"



int main(int argc, char const *argv[])
{
    char files[100][100],path1[100];
    strcpy(path1, argv[1]);
    int i,j;
    int NFiles = getAllFiles(files, path1);
    list hashHead[NFiles];
    if(NFiles <= 1)
    {
        printf("Number of text files should be greater than 1");
        exit(1);
    }
    FILE *fp[NFiles];
    for(i = 0 ; i < NFiles ; i ++)
    {
    	char path[100];
    	strcpy(path, argv[1]);
    	strcat(path, "\\");
    	strcat(path, files[i]);
        fp[i] = fopen(path, "r");
    }
    char *str[NFiles];
    for(i = 0 ; i < NFiles ; i++)
    {
        hashHead[i] = NULL;
        str[i] = getData(fp[i], 20);
        hashHead[i] = hash(hashHead[i], str[i]);
    }
    double prod[NFiles][NFiles];
    printf("File Name\t");
    for(i = 0 ; i < NFiles ; i++)
    {
    	printf("%s\t", files[i]);
    }
    printf("\n\n");
    for(i = 0 ; i < NFiles ; i++)
    {
    	printf("%s\t",files[i] );
        for(j = 0 ; j < NFiles ; j++)
        {
            if(i == j)
            {
                prod[i][j] = -1;
                printf("-1\t\t");
            }

            else if(i > j)
            {
                prod[i][j] = prod[j][i];
                printf("%.2f\t\t", prod[i][j]);
            }

            else
            {

                prod[i][j] = compare(hashHead[i], hashHead[j]);
                printf("%.2f\t\t", prod[i][j]);
            }

        }
        printf("\n\n");
    }

    return 0;
}
