#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/* This header file is the blueprint of linked list implementation*/
typedef struct node_type // defines  user data type node using structure
{
    int index;// index of the node in a linked list
	char *word;// a particular word in the string
	long countOfWord;// maintains a count of how many times a particular word appears. Initially this value is set to  1
	struct node_type *link;// link to the next node in list
}node;
typedef node *list;// declares a user data type list, a pointer to a node data type



