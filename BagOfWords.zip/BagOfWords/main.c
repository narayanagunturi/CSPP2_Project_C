#include <stdio.h>
#include <stdlib.h>
#include "Data.h"
#include "LinkedList.h"
#include <math.h>
#include <dirent.h>
#include <sys/types.h>
typedef node *list;
double vectorProduct(list head, list head1)
{
    /* This function calculates the dot product between the given two lists of words*/
    list temp1 = head;
    list temp2 = head1;
    double prod  =  0;
    while(temp1 != NULL)
    {
        int flag = 0;
        temp2 = head1;
        while(temp2 != NULL)
        {

            if(strcmp(temp1->word, temp2->word) == 0)
            {
                prod = prod + ((temp1->countOfWord)*(temp2->countOfWord));
                flag = 1;
            }
            temp2 = temp2->link;
            if(flag == 1)
                break;
        }
        temp1 = temp1->link;
    }

return prod;
}

double mod(list head)
{
    /* This function calculates the mod of the given list of word*/
    double squareSum = 0;
    list temp = head;
    while(temp != NULL)
    {
        squareSum += pow(temp->countOfWord, 2);
        temp = temp->link;
    }
    squareSum = sqrt(squareSum);
    return squareSum;

}
list createList(list head, char *str)
{
    /* This function creates a list of words for a given string*/
    int i = 0;
    list tail = head;
    list listTemp = NULL;;
    int index = 0;
    while(i < strlen(str))
    {

        while(i < strlen(str) && str[i] == ' ')
            i++;
        char *temp;
        int len = 20,j = 0;
        temp = realloc(NULL,sizeof(char)*len);
        while(i < strlen(str) && str[i] != ' ')
        {
            temp[j++] = str[i++];
            if(j == len)
            {
                temp = realloc(temp, sizeof(char)*(len));
            }

        }
        temp[j++] = '\0';
        if(strcmp(temp, "") == 0)
            continue;
        if(index == 0)
        {
            head = (list)malloc(sizeof(node));
            head->countOfWord = 1;
            head->index = index;
            head->link = NULL;
            head->word = temp;
            tail = head;
            index++;
        }
        else
        {
        listTemp = (list)malloc(sizeof(node));
        listTemp->word = temp;
        listTemp->index = index;
        index++;
        listTemp->countOfWord = 1;
        tail->link = listTemp;
        tail = tail->link;
        tail->link = NULL;
        }

    }
    return head;

}

void countAndDel(list head)
{
    /*This function removes duplicate words for a word in the given list
    and increases the count for that particular word*/
    list i, j, temp;
    i = head;
    while(i != NULL && i->link != NULL)
    {
        j = i;
        while(j->link != NULL)
        {
            if(strcmp(j->link->word, i->word) == 0)
            {
                i->countOfWord++;
                temp = j->link;
                j->link = j->link->link;
                free(temp);
            }
            else{
                j = j->link;
            }
        }
        i = i->link;


    }
}
int main(int argc, char const *argv[])
{
    char f[50];
    // copies the given command line argument to a character array f.
    strcpy(f,argv[1]);
    char files[100][100];
    int i,j;
    int NFiles = getAllFiles(files, f);
    if(NFiles <= 1)
    {
        printf("Number of text files should be greater than 1");
        exit(1);
    }
    FILE *fp[NFiles];
    for(i = 0 ; i < NFiles ; i ++)
    {
        char path1[50];
        strcpy(path1, f);
        strcat(path1, "\\");
        strcat(path1,files[i] );
        fp[i] = fopen(path1, "r");
    }
    char *str[NFiles];
    list head[NFiles];
    for(i = 0 ; i < NFiles ; i++)
    {
        head[i] = NULL;
        str[i] = getData(fp[i], 10);
        head[i] = createList(head[i], str[i]);
        countAndDel(head[i]);

    }
    double prod[NFiles][NFiles];
    printf("File Name\t");
    for(i = 0 ; i < NFiles ; i++)
    {
        printf("%s\t", files[i]);
    }
    printf("\n\n");
    for(i = 0 ; i < NFiles ; i++)
    {
        printf("%s\t", files[i]);
        for(j = 0 ; j < NFiles ; j++)
        {
            if(i == j)
            {
                prod[i][j] = -1;
                printf("-1\t\t");
            }

            else if(i > j)
            {
                prod[i][j] = prod[j][i];
                printf("%.2f\t\t", prod[i][j]);
            }

            else
            {
                prod[i][j] = ((vectorProduct(head[i], head[j]))/(mod(head[i])*mod(head[j])))*100;
                printf("%.2f\t\t", prod[i][j]);
            }

        }
        printf("\n\n");
    }
    return 0;
}
