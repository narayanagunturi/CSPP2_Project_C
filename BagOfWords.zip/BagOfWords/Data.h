#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>

char *getData(FILE* fp, size_t size){

    /* This function gets all the data in the file except special characters
    except "_" into a string and returns that string. It takes two arguments , file and default size */
    char *str;
    int ch;
    size_t len = 0;
    str = realloc(NULL, sizeof(char)*size);//allocates space for str
    if(!str)return str;
    while(EOF!=(ch=fgetc(fp))){
        if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch == '_') || (ch >= '0' && ch <= '9'))//takes only alphabets, "_", and numbers
        {
            if(ch >= 'A' && ch <= 'Z')//converts capital letters into small letters
                ch = ch + 32;
            str[len++]=ch;//puts each character into the string and increments len

        }

        else
            str[len++] = ' ';//if ch is a special character except "_", it inserts space
        if(len==size){
            str = realloc(str, sizeof(char)*(size+=20));//if len exceeds size, size is incremented by 20 and the same is reallocate to str
            if(!str)return str;
        }
    }
    str[len++]='\0';//At the end a null character is entered

    return realloc(str, sizeof(char)*len);
}

int getAllFiles(char files[100][100], char path[50])
{
    /* This function returns an array of all text files present in the given directory*/
	DIR *dir;
	struct dirent* f;
	dir = opendir(path);
	int i = 0;
	while((f = readdir(dir)) != NULL)//puts all files into f one by one
	{
		if (!strcmp (f->d_name, "."))//checks if f is current directory
            continue;
        if (!strcmp (f->d_name, ".."))//checks if f is parent directory
            continue;
        int len = strlen(f->d_name);
        if((f->d_name[len-1] == 't') && (f->d_name[len-2] == 'x') && (f->d_name[len-3] == 't') && (f->d_name[len-4] == '.'))//checks for .txt file
        	{
        		char *temp = (char*)malloc(sizeof(char)*100);
        		temp = f->d_name;
        		strcpy(files[i], temp);// if it is a text file, it is copied into the array

        		i++;
	        }
	}
	int noOfFiles = i;
	return noOfFiles;// number of .txt files is returned
}
