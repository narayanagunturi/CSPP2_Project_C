#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Data.h"
void plagLcs(char *path) // This function takes character array as an argument and prints the plagiarism matrix for the given text files.
{
    char files[100][100];
    int i, j, NFiles = getAllFiles(files, path);// This function puts all the .txt files into files array and returns number of files in the given path.
    if(NFiles <= 1)// This function requires more than one file to do plagiarism check. So it exits if number of files are less than 2.
    {
        printf("Number of text files should be greater than 1");
        exit(1);
    }
    FILE *fp[NFiles];
    for(i = 0 ; i < NFiles ; i ++)
    {
        char path1[100];
        strcpy(path1, path);
        strcat(path1, "\\");
        strcat(path1, files[i]);
        fp[i] = fopen(path1, "r");
    }
    char *str[NFiles];
    for(i = 0 ; i < NFiles ; i++)
    {
        str[i] = getData(fp[i], 10);
    }
    double prod[NFiles][NFiles];
    printf("File Name\t");
    for(i = 0 ; i < NFiles ; i++)
    {
        printf("%s\t", files[i]);
    }
    printf("\n\n");
    for(i = 0 ; i < NFiles ; i++)
    {
        printf("%s\t", files[i]);
        for(j = 0 ; j < NFiles ; j++)
        {
            if(i == j)
            {
                prod[i][j] = -1;
                printf("-1\t\t");
            }

            else if(i > j)
            {
                prod[i][j] = prod[j][i];
                printf("%.2f\t\t", prod[i][j]);
            }

            else
            {
                prod[i][j] = compare(str[i], str[j]);
                printf("%.2f\t\t", prod[i][j]);
            }

        }
        printf("\n\n");
    }
}
