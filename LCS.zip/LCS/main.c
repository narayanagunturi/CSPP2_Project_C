#include <stdio.h>
#include "LinkedList.h"
#include "PlagLcs.h"

int main(int argc, char const *argv[])
{
    char path[100];
    // copies the path given in command line argument to variable path
    strcpy(path, argv[1]);
    //calls the plagLcs method in plagLcs.h header file
    plagLcs(path);
    return 0;
}
