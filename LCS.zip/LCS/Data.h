#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
int getAllFiles(char files[100][100], char path[100])
{
    /* This functio gets all the .txt files in the given path*/
	DIR *dir;
	struct dirent* f;
	dir = opendir(path);
	int i = 0;
	while((f = readdir(dir)) != NULL)// puts each file in the given path into f one by one
	{
		if (!strcmp (f->d_name, "."))// checks for current directory
            continue;
        if (!strcmp (f->d_name, ".."))// checks for parent directory
            continue;
        int len = strlen(f->d_name);
        if((f->d_name[len-1] == 't') && (f->d_name[len-2] == 'x') && (f->d_name[len-3] == 't') && (f->d_name[len-4] == '.'))
        	{
                // tests for .txt files
        		char *temp = (char*)malloc(sizeof(char)*100);
        		temp = f->d_name;
        		//printf("%s\n", temp);
        		strcpy(files[i], temp);
        		//printf("%s\n", files[i]);
        		i++;
	        }
	}
    // returns number of files
	int noOfFiles = i;
	return noOfFiles;
}
char *getData(FILE* fp, size_t size){
// This function  gets all the data in .txt file except special characters and puts it in a string and returns it
    char *str;
    int ch;
    size_t len = 0;
    str = realloc(NULL, sizeof(char)*size);//size is start size
    if(!str)return str;
    while(EOF!=(ch=fgetc(fp))){
        if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch == '_') || (ch >= '0' && ch <= '9'))
        {
            if(ch >= 'A' && ch <= 'Z')
                ch = ch + 32;
            str[len++]=ch;

        }

        else
            str[len++] = ' ';
        if(len==size){
            str = realloc(str, sizeof(char)*(size+=16));// if the size of the given string exceeds previous size, some more memory is allocated to it.
            if(!str)return str;
        }
    }
    str[len++]='\0';// puts null at the end of the string
    return realloc(str, sizeof(char)*len);
}

double compare(char *str1, char* str2)
{
    /* This function compares the two strings and returns the plagiarism percentage */
    int i,j;
    int beg= 0,end=0;
    /* Finds the length of the longest common substring */
    for(i = 0 ; i < strlen(str1) ; i++)
    {
        int itemp = i;
        for(j = itemp ; j < strlen(str2) ; j++)
        {
            if (itemp < strlen(str1))
            {
                if(str1[itemp] == str2[j])
                {
                    itemp++;
                }
                else
                {
                    if((end-beg) < (itemp - i))
                    {
                        beg = i;
                        end = itemp;
                    }
                    itemp = i;
                    continue;
                }
            }
            else{
                break;
            }
        }
        if((end - beg) < (itemp - i))
        {
            beg = i;
            end = itemp;
        }
        if(itemp == strlen(str1))
        {
            break;
        }

    }
    double den = strlen(str1)+strlen(str2);// adds the lengths of the two given strings
    double num = (end- beg+1)*2;// length of thee longest common substring * 2 
    return (num/den)*100;// returns plagiarism percentage

}
